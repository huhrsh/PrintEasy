const express=require('express')

const router=express.Router();

router.use('/users',require('./user'))

console.log("Main router Loaded");

module.exports=router;