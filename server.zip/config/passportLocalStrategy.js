const passport=require('passport')
const localStrategy=require('passport-local').Strategy;
const User=require('../models/user')

passport.use(new localStrategy({
    usernameField:'email',
    passReqToCallback:true
    },
    function(email,password,done){
        User.findOne({email:email})
        .then((userFound)=>{
            if(!userFound){
                // res.send("User does not exit")
                console.log("User does not exit")
                return done(null,false)
            }
            if(!userFound.verifyPassword(password)){
                // res.send("Password does not match")
                console.log("Password does not match")
                return done(null,false)
            }
            // res.send("Signed in.")
            console.log("Signed in.")
            return done(null,userFound);
        })
        .catch((err)=>{
            return done(err);
        })
    }
))

passport.serializeUser((user,done)=>{
    done(null,user.id);
})

passport.deserializeUser((id,done)=>{
    console.log("lasan")
    User.findById(id)
    .then((userFound)=>{
        console.log("User is: ",userFound)
        done(null,userFound);
    })
    .catch((err)=>{
        done(err);
    })
})

passport.checkAuthentication=function(req,res,next){
    if(req.isAuthenticated()){
        console.log("No shit")
        return next();
    }
    else{
        console.log("Shit")
        return res.send("Error Authenticating");
    }
}

passport.setAuthenticatedUser=function(req,res,next){
    console.log("Inside Set Authenticater",req.user);
    if(req.isAuthenticated()){
        res.json(req.user);
    }
    next();
}

module.exports=passport