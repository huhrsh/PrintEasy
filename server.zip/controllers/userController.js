const User=require('../models/user')

module.exports.signUp=function(req,res){
    console.log("Sign up controller");
    User.findOne({email:req.body.email})
    .then((user)=>{
        if(user){
            return res.send("Email already in use")
        }
        else{
            User.create(
                req.body
            )
            .then((newUser)=>{
                console.log("New User ",newUser);
                return res.send("Account created");
            })
            .catch((err)=>{
                return res.send("Error in creating account");
            })
        }
    })
    .catch((err)=>{
        res.send("Error in creating account");
        return;
    })
    console.log(req.body);
}

module.exports.signIn=async function(req,res){
    console.log(req.body);
    console.log("Sign In controller");
    try {
        const userFound = await User.findOne({email:req.body.email });

        if (!userFound) {
            return res.send( "Invalid credentials" );
        }

        if (userFound.password !== req.body.password) {
            return res.send("Incorrect password");
        }

        // If sign-in is successful, send user data in the response
        return res.json({
            message: "Signed in successfully",
            user:userFound
        });
    } catch (error) {
        console.error("Error during sign-in:", error);
        return res.send("Error in signing in" );
    }
}

module.exports.signOut=(req,res)=>{
    req.logout();
    return res.send("Signed out successfully")
}

module.exports.getUserData=(req,res)=>{
    console.log(req.body)
    console.log("Yamete");
    console.log(req.user);
    return res.json(req.user);
}