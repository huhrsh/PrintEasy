import { Link } from "react-router-dom"
import { toast } from "react-toastify"
import { useState} from "react"
import { useNavigate } from "react-router-dom"
import { useDispatch } from "react-redux"
import {setUser} from '../Redux'

function SignIn(){
    const dispatch=useDispatch();

    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")

    const navigate=useNavigate();

    async function handleSubmit(e){
        e.preventDefault();
        let formData={email,password}
        let data;
        // console.log(formData);
        try {
            const response = await fetch('http://localhost:5000/users/sign-in', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(formData),
              credentials:"include",
            });
            // if(response.ok){
            //   toast.success("Signed in successfully");
            //   navigate('/');
            // }
            // else{
            //   toast.error("Sign in failed");
            // }
            data=await response.json();
            console.log("Response.text: ", data); // handle the response from the server
          } catch (error) {
            console.error('Error submitting form:', error);
        }
        setEmail("");
        setPassword("");
        if(data.user){
          dispatch(setUser(data.user));
          toast.success("Signed in successfully")
          // const user=data.user;
          navigate('/');
        }
        else if(data==='Password does not match'){
          toast.warn("Password does not match")
        }
        else{
          toast.error("User does not exist");
        }
      } 


    return (
        <>
            <main className="sign-in">
                <h2 className="sign-heading">Sign In</h2>
                <form method="post" onSubmit={(e)=>{handleSubmit(e)}} className="sign-form">
                    <input value={email} onChange={(e)=>{setEmail(e.target.value)}} className="sign-input" type="email" placeholder="email" autoFocus/>
                    <input value={password} onChange={(e)=>{setPassword(e.target.value)}} className="sign-input" type="password" placeholder="password"/>
                    <button type="submit">Sign In</button>
                </form>
                <Link className="google">Sign In using Google</Link>
                <Link to= '/sign-up' className='redirect-sign'>Don't have an account? Sign up here</Link>
            </main>
        </>
    )
}

export {SignIn}