// import { useEffect } from "react"
import {Link} from "react-router-dom"

function Home(){

    return(
        <>
            <main className="home">
                {/* <div className="location-div">
                    <div className="shop-name-container"></div>
                </div> */}

                <div className="home-options">
                    <Link to='/send-file' className="send single-option">
                        {/* <img className="send-image" src='https://img.freepik.com/free-vector/mail-sent-concept-illustration_114360-96.jpg?size=626&ext=jpg&uid=R95045313&ga=GA1.1.1294546411.1698236110&semt=sph' alt="send" /> */}
                        <div className="inside-option">
                            Send File/s
                        </div>
                    </Link>
                    <Link to='/receive-file' className="receive single-option">
                        {/* <img className="send-image" src='https://img.freepik.com/free-vector/mail-sent-concept-illustration_114360-96.jpg?size=626&ext=jpg&uid=R95045313&ga=GA1.1.1294546411.1698236110&semt=sph' alt="send" /> */}
                        <div className="inside-option">
                            Receive File/s
                        </div>
                    </Link>
                    <Link to='/print-file' className="print single-option">
                        {/* <img className="send-image" src='https://img.freepik.com/free-vector/mail-sent-concept-illustration_114360-96.jpg?size=626&ext=jpg&uid=R95045313&ga=GA1.1.1294546411.1698236110&semt=sph' alt="send" /> */}
                        <div className="inside-option">
                            Print File/s
                        </div>
                    </Link>
                </div>

            </main>
        </>
    )
}

export {Home}