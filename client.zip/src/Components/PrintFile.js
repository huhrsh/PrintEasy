function PrintFile(){
    return(
        <>
            <main className="print-main">
                Print
            </main>
        </>
    )
}

export {PrintFile}