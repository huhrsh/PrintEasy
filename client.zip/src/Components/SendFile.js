import { useState } from "react";

function SendFile() {
    // upload preview done 
    const [state,setState]=useState("upload")
    const [fileData,setFileData]=useState();

    function handleDrop(e){
        e.preventDefault();
        console.log(e.dataTransfer.files);
        setFileData(e.dataTransfer.files);
        setState("preview");
    }

    function handleChoose(e){
        // console.log(e);
        const files=document.getElementsByClassName('choose-file')[0];
        setFileData(files.files);
        console.log(files.files);
        setState("preview")
    }

    return (
        <>
            {
            state==="upload"?<form className="send-form">
                <p className="drop-p" >Drag and drop your files here</p>
                <div className="drop-area" onDrop={(e)=>{handleDrop(e)}} onDragOver={(e)=>{e.preventDefault()}}>
                    <div className="drop-cover">
                        <img className="drop-plus" src="https://cdn-icons-png.flaticon.com/128/32/32563.png" alt="plus"/>
                    </div>
                </div>
                <div className="select-files">
                    <p className="drop-p">Or select files here</p>
                    <input type="file" multiple className="choose-file" onChange={(e)=>{handleChoose(e)}}/>   
                </div>
            </form>:<></>
            }
            {
                state==="preview"?
                <>
                    <main className="send-main">
                        <h2 className="send-heading">Uploaded Files</h2>
                        <div className="preview-section">
                            {Object.values(fileData).map((item,index)=>(
                                <div className="item-preview-container" key={index}>
                                    {item.type==='application/pdf'&&<iframe src={`${URL.createObjectURL(item)}#page=1`} className="item-preview-image" title="PDF Viewer" />}
                                    {item.type.startsWith('image/')&&<img className="item-preview-image" src={URL.createObjectURL(item)} alt="item"/>}
                                    {(item.type!=='application/pdf' & item.type.startsWith('image')===false )&&<img className="item-preview-image-default" src='https://cdn-icons-png.flaticon.com/128/2541/2541988.png' alt="item"/>}
                                    <p className="preview-name">{item.name.split('.')[0]}</p>
                                </div>
                            ))}
                        </div>
                        <div className="cancel-upload">
                            <button className="cancel-button" onClick={()=>{setState("upload")}}>Cancel</button>
                            <button className="upload-button" onClick={()=>{setState("done")}}>Upload</button>
                        </div>
                    </main>
                </>:<></>
            }
        </>
    )
}

export { SendFile }