import { Link, Outlet } from "react-router-dom"
import {useSelector} from "react-redux";
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch } from 'react-redux';
import { setUser } from "../Redux";
import { useEffect } from 'react';
import { toast } from "react-toastify";

function Navbar(){

    const dispatch=useDispatch();   
    let user; 
    useEffect(() => {
        const fetchUserData = async () => {
            try {
              const response = await fetch('http://localhost:5000/users/get-user-data');

              const userData = await response.json();
      
              if (userData) {
                dispatch(setUser(userData));
              }
            } catch (error) {
              console.error('Error fetching user data:', error);
              toast.error('Error fetchin '+new Date().getTime());
            }
          };
          fetchUserData();
    }, []);

    user=useSelector((state)=>state.user.user);
    console.log(user)

    return(
        <>
            <header className="navbar">
                <Link to='/' className="printeasy-heading">
                    <img className="printeasy-img" alt="logo" src="https://cdn-icons-png.flaticon.com/128/2248/2248661.png"/>
                    PrintEasy
                </Link>
                {user===null?
                <Link to='/sign-in' className="user">
                    <img src="https://cdn-icons-png.flaticon.com/128/456/456212.png" alt="user"/> Sign In
                </Link>:
                    <div className="signed-user-nav">
                        <Link to='/sign-in' className="user">
                            <img src="https://cdn-icons-png.flaticon.com/128/456/456212.png" alt="user"/> {user.name}
                        </Link>
                    </div>
                }
            </header>
            <ToastContainer />
            <Outlet/>
        </>
    )
}

export {Navbar}