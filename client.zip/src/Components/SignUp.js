import { useState } from "react";
import { Link,useNavigate } from "react-router-dom"
import { toast } from "react-toastify";

function SignUp(){
    const [name,setName]=useState("")
    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")

    const navigate=useNavigate();

    async function handleSubmit(e){
        e.preventDefault();
        let formData={name,email,password}
        let data;
        // console.log(formData);
        try {
            const response = await fetch('http://localhost:5000/users/sign-up', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(formData),
            });
        
            data = await response.text();
            console.log("Response.text: ",data); // handle the response from the server
          } catch (error) {
            console.error('Error submitting form:', error);
        }
        setName("");
        setEmail("");
        setPassword("");
        // console.log(data==='Email already in use.');
        if(data==='Account created'){
          toast.success("Account created")
          navigate('/sign-in');
        }
        else if(data==='Email already in use'){
          toast.warn("Email already in use")
        }
        else{
          toast.error("Error in creating account");
        }
      } 

    return (
        <>
            <main className="sign-up">
                <h2 className="sign-heading">Sign Up</h2>
                <form method="post" onSubmit={(e)=>{handleSubmit(e)}} className="sign-form">
                    <input onChange={(e)=>{setName(e.target.value)}} value={name} type="text" placeholder="name" autoFocus/>
                    <input onChange={(e)=>{setEmail(e.target.value)}} value={email} type="email" placeholder="email"/>
                    <input onChange={(e)=>{setPassword(e.target.value)}} value={password} type="password" placeholder="password"/>
                    <button type="submit">Sign Up</button>
                </form>
                <Link to='/' className="google">Sign In using google</Link>
                <Link to= '/sign-in' className='redirect-sign'>Already have an account? Sign in here</Link>
            </main>
        </>
    )
}

export {SignUp}