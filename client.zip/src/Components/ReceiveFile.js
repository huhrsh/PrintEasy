function ReceiveFile(){
    return(
        <>
            <main className="receive-main">
                
            </main>
        </>
    )
}

export {ReceiveFile}