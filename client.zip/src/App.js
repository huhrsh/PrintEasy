import './App.css';
import { createBrowserRouter,RouterProvider } from 'react-router-dom';
import { Navbar } from './Components/Navbar';
import { Home } from './Components/Home';
import { Provider } from 'react-redux';
import { store } from './Redux';
import { SignIn } from './Components/SignIn';
import { SignUp } from './Components/SignUp';
import { SendFile } from './Components/SendFile';
import { ReceiveFile } from './Components/ReceiveFile';
import { PrintFile } from './Components/PrintFile';


function App() {
  const router=createBrowserRouter([
    {
      path:"/",
      element:<Navbar/>,
      children:[
        {index:true, element:<Home/>},
        {path:"sign-in", element:<SignIn/>},
        {path:"sign-up", element:<SignUp/>},
        {path:"send-file", element:<SendFile/>},
        {path:"receive-file", element:<ReceiveFile/>},
        {path:"print-file", element:<PrintFile/>},
      ],
      // errorElement:<ErrorPage/>
    }
  ])

  return (
    <Provider store={store}>
      <RouterProvider router={router}/>
    </Provider>
    );

  }

export default App;
